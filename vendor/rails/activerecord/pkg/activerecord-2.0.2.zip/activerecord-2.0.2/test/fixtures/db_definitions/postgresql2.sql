CREATE TABLE courses (
  id serial primary key,
  name text
);
