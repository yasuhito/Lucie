DROP TABLE courses
go
