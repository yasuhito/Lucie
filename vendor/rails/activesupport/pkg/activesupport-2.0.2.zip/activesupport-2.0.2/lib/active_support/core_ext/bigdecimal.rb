require 'bigdecimal'
require 'active_support/core_ext/bigdecimal/conversions'
