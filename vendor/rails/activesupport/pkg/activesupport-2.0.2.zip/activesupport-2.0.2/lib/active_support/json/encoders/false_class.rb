class FalseClass
  def to_json(options = nil) #:nodoc:
    'false'
  end
end
